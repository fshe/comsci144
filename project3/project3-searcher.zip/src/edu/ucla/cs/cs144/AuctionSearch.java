package edu.ucla.cs.cs144;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import edu.ucla.cs.cs144.DbManager;
import edu.ucla.cs.cs144.SearchRegion;
import edu.ucla.cs.cs144.SearchResult;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class AuctionSearch implements IAuctionSearch {

	/* 
         * You will probably have to use JDBC to access MySQL data
         * Lucene IndexSearcher class to lookup Lucene index.
         * Read the corresponding tutorial to learn about how to use these.
         *
	 * You may create helper functions or classes to simplify writing these
	 * methods. Make sure that your helper functions are not public,
         * so that they are not exposed to outside of this class.
         *
         * Any new classes that you create should be part of
         * edu.ucla.cs.cs144 package and their source files should be
         * placed at src/edu/ucla/cs/cs144.
         *
         */
	private IndexSearcher searcher = null;
	private QueryParser parser = null;
	
	public AuctionSearch() throws IOException {
		searcher = new IndexSearcher(DirectoryReader.open(FSDirectory.open(new File("/var/lib/lucene/index"))));
		parser = new QueryParser("content", new StandardAnalyzer());
	}
		
	public SearchResult[] basicSearch(String query, int numResultsToSkip, 
			int numResultsToReturn) {
		SearchResult[] results = null;
		try {
		Query q = parser.parse(query);
		TopDocs td = searcher.search(q, numResultsToSkip+numResultsToReturn);
		ScoreDoc[] hits = td.scoreDocs;
		if(hits.length > numResultsToSkip)
			results = new SearchResult[hits.length - numResultsToSkip];
		else
			return new SearchResult[0];
		for(int i = numResultsToSkip; i < hits.length; i++ )
		{
			Document doc = searcher.doc(hits[i].doc);
			results[i-numResultsToSkip] = new SearchResult(doc.get("id"), doc.get("name"));
		}
		} catch(ParseException e) {} 
		catch(IOException e) {}	
		return results;
	}



	public SearchResult[] spatialSearch(String query, SearchRegion region,
			int numResultsToSkip, int numResultsToReturn) {
		Connection c = null;
		try {
			c = DbManager.getConnection(true);
		} catch (SQLException e) { 
			System.out.println("SQLException caught at spatialSearch()");
		}
		HashMap<Integer, String> matches = new HashMap<Integer, String>();
		HashMap<Integer, Integer> hashedResults = new HashMap<Integer, Integer>();		
		int itemID;
		String name;

		try {
		Statement s = c.createStatement();
		ResultSet rs = s.executeQuery("SELECT ItemID FROM SpatialLocation WHERE X(locPoint) > " + region.getLx() + " AND X(locPoint) < " + region.getRx() + " AND Y(locPoint) > " + region.getLy() + " AND Y(locPoint) < " + region.getRy());
		while(rs.next())
		{
			itemID = rs.getInt("ItemID");
			hashedResults.put(itemID, 0);
		}
		s.close();
		rs.close();
		} catch(SQLException e) {System.out.println("SQLException: " + e.getMessage());
		}

		boolean loop = true;
		int amount = 0;
		int id;
		while( loop == true )
		{
			SearchResult[] results = basicSearch(query, amount, 10000);
			amount += 10000;
			if (results.length < 10000)
				loop = false;
			for(int i = 0; i < results.length; i++)
			{
				id = Integer.parseInt(results[i].getItemId());
				if(hashedResults.get(id) != null)
					hashedResults.put(id, 1);
					matches.put(id, results[i].getName());
			}
		}
		int count = 0; //count total in the result
		//now check for what contains a 1, those are the results.
		Iterator<Map.Entry<Integer, Integer>> iterator = hashedResults.entrySet().iterator();
		while(iterator.hasNext())
		{
			Map.Entry<Integer, Integer> entry = iterator.next();
			if(entry.getValue() == 0)
				iterator.remove();
			else
				count++;
		}
		int i = 0;
		SearchResult[] finalResults = new SearchResult[count];
		Iterator<Map.Entry<Integer, Integer>> iterator2 = hashedResults.entrySet().iterator();
		while(iterator2.hasNext())
		{
			Map.Entry<Integer, Integer> entry2 = iterator2.next();
			int key = entry2.getKey();
			finalResults[i] = new SearchResult(Integer.toString(key), matches.get(key));
			i++;
		}	
		return finalResults;
	}

	public String parseTime(String oldTimeString) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String returnString = "";
		try {
			Date parsed = sdf.parse(oldTimeString);
			sdf.applyPattern("MMM-dd-yy HH:mm:ss");
			returnString = sdf.format(parsed);
		} catch (java.text.ParseException e) {
			System.out.println("Caught java.text.ParseException");
		}
		return returnString;
	}

	public String getXMLDataForItemId(String itemId) {
		Connection c = null;
		try {
			c = DbManager.getConnection(true);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
		}
	
		String XMLtoReturn = "";	
		int itemID = Integer.parseInt(itemId);
		String name = "";
		double Currently=0;
		double Buy_Price= 0; //not required
		double First_Bid=0;
		int Number_of_Bids=0;
		String Started = "";
		String Ends = "";
		String Location="";
		float Latitude =0 ;  //not required
		float Longitude=0; //not required
		boolean lat = false;
		boolean lon = false;
		String Country="";
		String SellerID = "";
		String Description="";
		int Rating=0;
		ArrayList<String> categories = new ArrayList<String>();

		try {
		Statement s = c.createStatement();
		//Query Item Table
		ResultSet rs = s.executeQuery("SELECT * from Item WHERE ItemID = " + itemID);
		while(rs.next())
		{
			name = rs.getString("Name");
			Currently = rs.getDouble("Currently");
			Buy_Price = rs.getDouble("Buy_Price");
			First_Bid = rs.getDouble("First_Bid");	
			Number_of_Bids = rs.getInt("Number_of_Bids");
			Started = parseTime(rs.getString("Started"));
			Ends = parseTime(rs.getString("Ends"));
			Location = rs.getString("Location");
			Latitude = rs.getFloat("Latitude");
			Longitude = rs.getFloat("Longitude");
			if (rs.getFloat("Latitude") != 0)
				lat = true;
			if (rs.getFloat("Longitude") != 0)
				lon = true;
			Country = rs.getString("Country");
			SellerID = rs.getString("SellerID");
			Description = rs.getString("Description");
			
		}
		if (name.equals("")) //itemID was not found
			return "";
		//Query User Table
		rs = s.executeQuery("SELECT Rating FROM User WHERE UserID = '" + SellerID + "'");
		while(rs.next())
		{
			Rating = rs.getInt("Rating");
		}
		//Query Category Table
		rs = s.executeQuery("SELECT Category FROM Category WHERE ItemID = " + itemID);
		while(rs.next())
		{
			categories.add(rs.getString("Category"));
		}
		//Query Bid Table
		rs = s.executeQuery("SELECT * FROM Bid WHERE ItemID = " + itemID);
		String bidsXML = "\t<Bids>\n";
		while(rs.next())
		{
			bidsXML += "\t\t<Bid>\n";
			bidsXML += "\t\t\t<Bidder Rating=\""+rs.getInt("Rating")+"\" UserID=\""+rs.getString("UserID")+"\">\n";			
			if(rs.getString("Location") != null)
				bidsXML+= "\t\t\t\t<Location>"+rs.getString("Location")+"</Location>\n";
			if(rs.getString("Country") != null)
				bidsXML+= "\t\t\t\t<Country>"+rs.getString("Country")+"</Country>\n";
			bidsXML+="\t\t\t</Bidder>\n";
			bidsXML+="\t\t\t<Time>"+parseTime(rs.getString("Time"))+"</Time>\n";
			bidsXML+="\t\t\t<Amount>"+rs.getDouble("Amount")+"</Amount>\n";
			bidsXML+="\t\t</Bid>\n";
		}	
		if (bidsXML.equals("\t<Bids>\n"))
			bidsXML = "\t<Bids />\n";
		//build the Categories XML
		String categoryXML = "";
		for(int i = 0; i < categories.size(); i++)
		{
			categoryXML += "\t<Category>" + categories.get(i) + "</Category>\n";
		}
		//combine into full XML
		XMLtoReturn += "<Item ItemID=\""+itemID+"\">\n";
		XMLtoReturn += "\t<Name>"+name+"</Name>\n";
		XMLtoReturn += categoryXML;
		XMLtoReturn += "\t<Currently>$"+String.format("%.2f", Currently)+"</Currently>\n";
		if (Buy_Price!= 0)
			XMLtoReturn +="\t<Buy_Price>$"+String.format("%.2f", Buy_Price)+"</Buy_Price>\n";
		XMLtoReturn += "\t<First_Bid>$"+String.format("%.2f", First_Bid)+"</First_Bid>\n";
		XMLtoReturn += "\t<Number_of_Bids>"+Number_of_Bids+"</Number_of_Bids>\n";
		XMLtoReturn += bidsXML;
		XMLtoReturn += "\t<Location";
		if(lat == true)
			XMLtoReturn += " Latitude=\""+String.format("%.6f", Latitude)+"\"";
		if(lon == true)
			XMLtoReturn += " Longitude=\""+String.format("%.6f", Longitude)+"\"";
		XMLtoReturn += ">"+Location+"</Location>\n";
		XMLtoReturn += "\t<Country>"+Country+"</Country>\n";
		XMLtoReturn += "\t<Started>"+Started+"</Started>\n";
		XMLtoReturn += "\t<Ends>"+Ends+"</Ends>\n";
		XMLtoReturn += "\t<Seller Rating=\""+Rating+"\" UserID=\""+SellerID+"\" />\n";
		XMLtoReturn += "\t<Description>"+Description+"</Description>\n";
		XMLtoReturn += "</Item>";
	
		s.close();
		rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: " +e.getMessage());
		}	
		return XMLtoReturn;
	}
	
	public String echo(String message) {
		return message;
	}

}
