This example contains a simple utility class to simplify opening database
connections in Java applications, such as the one you will write to build
your Lucene index. 

To build and run the sample code, use the "run" ant target inside
the directory with build.xml by typing "ant run".

I have decided to build Lucene Index on the union of the item name, category and description atttributes. I create this index to account for queries like "star AND trek" which should return the item if the matching words are found in the union of the attributes.
