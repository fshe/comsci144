ALTER TABLE SpatialLocation DROP INDEX locPoint;
DROP TABLE IF EXISTS SpatialLocation;
