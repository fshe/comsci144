DROP TABLE IF EXISTS SpatialLocation;
CREATE TABLE SpatialLocation
	(ItemID INTEGER NOT NULL,
	locPoint POINT NOT NULL,
	SPATIAL INDEX(locPoint)) ENGINE=MyISAM;

INSERT INTO SpatialLocation(ItemID, locPoint)
SELECT ItemID, POINT(Latitude, Longitude) FROM Item;
